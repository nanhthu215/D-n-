public class Room {
    /* Code here */
}
