public class Villa extends LuxuryAccommodation {
    /* Code here */
}
