import java.util.ArrayList;

public class Resort extends CommonAccommodation {
    /* Code here */
}
