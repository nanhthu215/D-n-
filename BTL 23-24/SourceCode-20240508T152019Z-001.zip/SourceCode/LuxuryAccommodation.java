public class LuxuryAccommodation extends Accommodation {
    /* Code here */
}
