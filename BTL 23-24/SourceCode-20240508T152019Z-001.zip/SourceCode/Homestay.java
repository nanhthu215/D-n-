import java.util.ArrayList;

public class Homestay extends CommonAccommodation {
    /* Code here */
}
