import java.util.ArrayList;

public class Hotel extends CommonAccommodation {
    /* Code here */
}
