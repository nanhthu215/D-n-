public class CruiseShip extends LuxuryAccommodation {
    /* Code here */
}
