abstract class Accommodation {
    /* Code here */
}
